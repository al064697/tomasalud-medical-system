"""
config.py
--------------------
Lee las variables de entorno desde el archivo '.env'
para configurar la aplicación y la base de datos. 
"""

from pydantic import BaseSettings

class Settings(BaseSettings):
    DB_HOST: str
    DB_PORT: int
    DB_USER: str
    DB_PASSWORD: str
    DB_NAME: str
    SECRET_KEY: str = "default_secret"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

class Config:
    env_file=".env" # Se indica la lectura de .env

# Instancia global de configuración
settings = Settings()