"""
schemas/usuario.py
------------------
Esquemas Pydantic para validar y serializar los datos de usuarios.
"""

from pydantic import BaseModel
from datetime import date
from typing import Optional

class UsuarioBase(BaseModel):
    NOMBRE: str
    SEXO: str
    FECHA_NACIMIENTO: date
    TIPO_SANGRE: Optional[str] = None
    DONADOR_ORGANOS: Optional[bool] = False
    ALERGIAS: Optional[str] = None
    PADECIMIENTOS: Optional[str] = None
    ROL: Optional[str] = "USUARIO" # Nuevo

class UsuarioCreate(UsuarioBase):
    """Datos necesarios para crear un usuario"""
    pass

class UsuarioUpdate(UsuarioBase):
    """Datos opcionales para actualizar un usuario"""
    NOMBRE: Optional[str] = None
    SEXO: Optional[str] = None
    FECHA_NACIMIENTO: Optional[date] = None

class UsuarioOut(UsuarioBase):
    """Datos que se devuelven en las respuestas"""
    ID_USUARIO: int

    class Config:
        orm_mode = True