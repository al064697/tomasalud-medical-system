"""
models/usuario.py
-----------------
Define la tabla `USUARIO` en SQLAlchemy.
Representa a los usuarios del sistema, con sus datos personales y médicos.
"""

from sqlalchemy import Column, Integer, String, Date, Enum, Boolean, Text
from app.database import Base

class Usuario(Base):
    __tablename__ = "USUARIO"

    ID_USUARIO = Column(Integer, primary_key=True, index=True, autoincrement=True)
    NOMBRE = Column(String(50), nullable=False)
    SEXO = Column(String(1), nullable=False)
    FECHA_NACIMIENTO = Column(Date, nullable=False)
    TIPO_SANGRE = Column(Enum('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'), nullable=True)
    DONADOR_ORGANOS = Column(Boolean, default=False)
    ALERGIAS = Column(Text, nullable=True)
    PADECIMIENTOS = Column(Text, nullable=True)
    ROL = Column(Enum("ADMIN", "USUARIO", name="ROL_ENUM"), default="USUARIO")