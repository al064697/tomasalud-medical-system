"""
models/medicamento.py
---------------------
Define la tabla `MEDICAMENTO`.
Cada tratamiento puede tener múltiples medicamentos asociados.
"""

from sqlalchemy import Column, Integer, String, Time, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class Medicamento(Base):
    __tablename__ = "MEDICAMENTO"

    ID_MEDICAMENTO = Column(Integer, primary_key=True, index=True, autoincrement=True)
    ID_TRATAMIENTO = Column(Integer, ForeignKey("TRATAMIENTO.ID_TRATAMIENTO"), nullable=False)
    NOMBRE = Column(String(50), nullable=False)
    DOSIS = Column(String(50), nullable=False)
    HORA = Column(Time, nullable=False)
    OBSERVACION = Column(Text, nullable=True)
    INTERVALO = Column(Integer, nullable=True)  # Intervalo en horas

    # Relación con Tratamiento
    tratamiento = relationship("Tratamiento", backref="medicamentos")